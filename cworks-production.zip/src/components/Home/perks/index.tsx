const values = [
  {
    icon: "🌍",
    title: "Uganda-Based, Globally-Minded",
    text: "Deep local expertise with international quality standards",
    space: "lg:mt-8",
  },
  {
    icon: "🚀",
    title: "End-to-End Delivery",
    text: "From concept to deployment, we handle every phase",
    space: "lg:mt-14",
  },
  {
    icon: "⚡",
    title: "Performance Obsessed",
    text: "Every pixel, every query, every interaction optimized",
    space: "lg:mt-4",
  },
  {
    icon: "🤝",
    title: "Transparent Process",
    text: "Regular updates, clear timelines, no hidden costs",
    space: "lg:mt-8",
  },
];

const Perks = () => {
  return (
    <section className="pb-28 relative">
      <div className="container mx-auto lg:max-w-screen-xl px-4">
        <div className="text-center">
          <p className="text-muted sm:text-28 text-18 mb-4 pb-6 relative after:content-[''] after:w-8 after:h-0.5 after:bg-primary after:absolute after:bottom-0 after:left-1/2">
            Why <span className="text-primary">CWorks</span>
          </p>
          <h2 className="text-white sm:text-40 text-30 font-medium">
            What sets our Kampala-based agency apart
          </h2>
          <div className="mt-16 border border-border grid lg:grid-cols-4 sm:grid-cols-2 border-opacity-20 py-16 gap-10 px-20 rounded-3xl bg-dark_grey bg-opacity-35">
            {values.map((item, index) => (
              <div
                key={index}
                className="text-center flex items-center justify-end flex-col"
              >
                <div className="bg-primary bg-opacity-25 backdrop-blur-sm p-4 rounded-full w-fit">
                  <span className="text-3xl">{item.icon}</span>
                </div>
                <h4 className={`text-white text-24 mb-4 ${item.space}`}>
                  {item.title}
                </h4>
                <p className="text-muted text-opacity-60">
                  {item.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="bg-gradient-to-br from-tealGreen to-charcoalGray sm:w-50 w-96 sm:h-50 h-96 rounded-full sm:-bottom-80 bottom-0 blur-400 z-0 absolute sm:-left-48 opacity-60"></div>
    </section>
  );
};

export default Perks;
